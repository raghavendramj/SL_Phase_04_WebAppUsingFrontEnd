import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css'],
})
export class ParentComponent implements OnInit {
  // From Parent to Child Commnuication done using this variable
  inputMessage = '';

  postObjects = new Array();

  receivePost(data: any) {
    console.log(data);
    this.postObjects.push(data);
  }

  constructor() {}

  ngOnInit(): void {
    console.log('Text passed from parent is :- ', this.inputMessage);
  }
}
