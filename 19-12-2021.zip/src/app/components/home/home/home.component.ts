import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // Property Binded Field
  isDisabled = true;

  //Interpolation Field
  currValue = "Enable Email Field";

  //Two Way Binded Field
  username = "Raghavendra M J";


  //Class Binded Field
  divClass = "blueColoredDiv"

  //Class Binded Field -> Class List example
  divClassList = "first second third fourth";
  applied = false;  
  changeColorText = "Change BG To Red";


  //Style Binding
  colorPara = "blue";

  navStyle = 'font-size: 1.2rem; color: cornflowerblue;';
  linkStyle = 'underline';
  activeLinkStyle = 'overline';

  
  changeColorOfDiv(){

    this.applied = !this.applied;

    if(this.changeColorText === "Change BG To Red"){
      this.divClass = "redColoredDiv";
      this.colorPara = "coral";
      this.changeColorText = "Change BG To Blue";
    } else {
      this.divClass = "blueColoredDiv";
      this.colorPara = "lightblue";
      this.changeColorText = "Change BG To Red";
    }
  }

  constructor() { }

  ngOnInit(): void {
  }


  //Event Binded Function
  toggleInputElement(){
    this.isDisabled = !this.isDisabled;

    this.currValue = this.isDisabled ? "Enable" : "Disable";
    this.currValue += "Email Field";

    // if(!this.isDisabled){
    //   this.currValue = "Disable Email Field";
    // } else {
    //   this.currValue = "Enable Email Field";
    // }
  }

}
